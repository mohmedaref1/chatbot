from transformers import BartTokenizer, BartForConditionalGeneration
from transformers import BartTokenizer, TFBartForConditionalGeneration
from ar_corrector.corrector import Corrector
from nltk.tokenize import sent_tokenize
from docx.shared import RGBColor, Pt
from googletrans import Translator
from reportlab.lib.colors import *
import speech_recognition as sr
from bs4 import BeautifulSoup
from newspaper import Article
from langdetect import detect
from docx2pdf import convert
import language_tool_python
import moviepy.editor as mp
from docx import Document
from pathlib import Path
import soundfile as sf
from tqdm import tqdm
import requests
import PyPDF2
import random
import string
import os
import json
import hashlib
from django.utils import timezone
import re
import wikipediaapi
from googlesearch import search
import urllib.parse
from django.core.files.storage import default_storage
from django.shortcuts import render
from blog.models import Massages
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from .chatbot.main import chatbotans
import nltk
from django.http import JsonResponse
from transformers import T5Tokenizer, T5ForConditionalGeneration
from transformers import pipeline



nltk.download("punkt", quiet=True)
nltk.download("stopwords", quiet=True)
max_chunck_len = 1000
# enable when in server
#max_chunck_len = 2000

BASE_DIR = Path(__file__).resolve().parent.parent

video_extensions = ['.264', '.3g2', '.3gp', '.3gp2', '.3gpp', '.3gpp2', '.3mm', '.3p2', '.60d', '.787', '.89', '.aaf', '.aec', '.aep', '.aepx',
                        '.aet', '.aetx', '.ajp', '.ale', '.am', '.amc', '.amv', '.amx', '.anim', '.aqt', '.arcut', '.arf', '.asf', '.asx', '.avb',
                        '.avc', '.avd', '.avi', '.avp', '.avs', '.avs', '.avv', '.axm', '.bdm', '.bdmv', '.bdt2', '.bdt3', '.bik', '.bin', '.bix',
                        '.bmk', '.bnp', '.box', '.bs4', '.bsf', '.bvr', '.byu', '.camproj', '.camrec', '.camv', '.ced', '.cel', '.cine', '.cip',
                        '.clpi', '.cmmp', '.cmmtpl', '.cmproj', '.cmrec', '.cpi', '.cst', '.cvc', '.cx3', '.d2v', '.d3v', '.dat', '.dav', '.dce',
                        '.dck', '.dcr', '.dcr', '.ddat', '.dif', '.dir', '.divx', '.dlx', '.dmb', '.dmsd', '.dmsd3d', '.dmsm', '.dmsm3d', '.dmss',
                        '.dmx', '.dnc', '.dpa', '.dpg', '.dream', '.dsy', '.dv', '.dv-avi', '.dv4', '.dvdmedia', '.dvr', '.dvr-ms', '.dvx', '.dxr',
                        '.dzm', '.dzp', '.dzt', '.edl', '.evo', '.eye', '.ezt', '.f4p', '.f4v', '.fbr', '.fbr', '.fbz', '.fcp', '.fcproject',
                        '.ffd', '.flc', '.flh', '.fli', '.flv', '.flx', '.gfp', '.gl', '.gom', '.grasp', '.gts', '.gvi', '.gvp', '.h264', '.hdmov',
                        '.hkm', '.ifo', '.imovieproj', '.imovieproject', '.ircp', '.irf', '.ism', '.ismc', '.ismv', '.iva', '.ivf', '.ivr', '.ivs',
                        '.izz', '.izzy', '.jss', '.jts', '.jtv', '.k3g', '.kmv', '.ktn', '.lrec', '.lsf', '.lsx', '.m15', '.m1pg', '.m1v', '.m21',
                        '.m21', '.m2a', '.m2p', '.m2t', '.m2ts', '.m2v', '.m4e', '.m4u', '.m4v', '.m75', '.mani', '.meta', '.mgv', '.mj2', '.mjp',
                        '.mjpg', '.mk3d', '.mkv', '.mmv', '.mnv', '.mob', '.mod', '.modd', '.moff', '.moi', '.moov', '.mov', '.movie', '.mp21',
                        '.mp21', '.mp2v', '.mp4', '.mp4v', '.mpe', '.mpeg', '.mpeg1', '.mpeg4', '.mpf', '.mpg', '.mpg2', '.mpgindex', '.mpl',
                        '.mpl', '.mpls', '.mpsub', '.mpv', '.mpv2', '.mqv', '.msdvd', '.mse', '.msh', '.mswmm', '.mts', '.mtv', '.mvb', '.mvc',
                        '.mvd', '.mve', '.mvex', '.mvp', '.mvp', '.mvy', '.mxf', '.mxv', '.mys', '.ncor', '.nsv', '.nut', '.nuv', '.nvc', '.ogm',
                        '.ogv', '.ogx', '.osp', '.otrkey', '.pac', '.par', '.pds', '.pgi', '.photoshow', '.piv', '.pjs', '.playlist', '.plproj',
                        '.pmf', '.pmv', '.pns', '.ppj', '.prel', '.pro', '.prproj', '.prtl', '.psb', '.psh', '.pssd', '.pva', '.pvr', '.pxv',
                        '.qt', '.qtch', '.qtindex', '.qtl', '.qtm', '.qtz', '.r3d', '.rcd', '.rcproject', '.rdb', '.rec', '.rm', '.rmd', '.rmd',
                        '.rmp', '.rms', '.rmv', '.rmvb', '.roq', '.rp', '.rsx', '.rts', '.rts', '.rum', '.rv', '.rvid', '.rvl', '.sbk', '.sbt',
                        '.scc', '.scm', '.scm', '.scn', '.screenflow', '.sec', '.sedprj', '.seq', '.sfd', '.sfvidcap', '.siv', '.smi', '.smi',
                        '.smil', '.smk', '.sml', '.smv', '.spl', '.sqz', '.srt', '.ssf', '.ssm', '.stl', '.str', '.stx', '.svi', '.swf', '.swi',
                        '.swt', '.tda3mt', '.tdx', '.thp', '.tivo', '.tix', '.tod', '.tp', '.tp0', '.tpd', '.tpr', '.trp', '.ts', '.tsp', '.ttxt',
                        '.tvs', '.usf', '.usm', '.vc1', '.vcpf', '.vcr', '.vcv', '.vdo', '.vdr', '.vdx', '.veg', '.vem', '.vep', '.vf', '.vft',
                        '.vfw', '.vfz', '.vgz', '.vid', '.video', '.viewlet', '.viv', '.vivo', '.vlab', '.vob', '.vp3', '.vp6', '.vp7', '.vpj',
                        '.vro', '.vs4', '.vse', '.vsp', '.w32', '.wcp', '.webm', '.wlmp', '.wm', '.wmd', '.wmmp', '.wmv', '.wmx', '.wot', '.wp3',
                        '.wpl', '.wtv', '.wve', '.wvx', '.xej', '.xel', '.xesc', '.xfl', '.xlmv', '.xmv', '.xvid', '.y4m', '.yog', '.yuv', '.zeg',
                        '.zm1', '.zm2', '.zm3', '.zmv']

audio_extensions = ['.3ga', '.669', '.a52', '.aac', '.ab', '.abm', '.ac3', '.acd', '.acd', '.acm', '.act', '.adg', '.adp', '.ads', '.adt', '.adts',
                    '.adx', '.aea', '.afc', '.agm', '.ahx', '.aif', '.aifc', '.aiff', '.aimppl', '.akp', '.al', '.alac', '.alaw', '.all', '.amf', '.amr', '.ams',
                    '.ams', '.aob', '.ape', '.apf', '.apl', '.ase', '.at3', '.atrac', '.au', '.aud', '.aup', '.avastsounds', '.avr', '.awb', '.band', '.bap',
                    '.bdd', '.box', '.brstm', '.bwf', '.c01', '.caf', '.cda', '.cdlx', '.cdr', '.cel', '.cfa', '.cidb', '.cmf', '.copy', '.cpr', '.cpt', '.csh',
                    '.cwp', '.d00', '.d01', '.dcf', '.dcm', '.dct', '.ddt', '.dec', '.dff', '.dfl', '.dig', '.dls', '.dmf', '.dmsa', '.dmse', '.dmx', '.drg',
                    '.dsm', '.dsp', '.dss', '.dtm', '.dts', '.dtshd', '.dwd', '.efk', '.efa', '.efe', '.efk', '.efq', '.efr', '.efs', '.efv', '.efw', '.efx',
                    '.emd', '.emx', '.esy', '.f2r', '.f32', '.f3r', '.f4a', '.f64', '.far', '.fff', '.flac', '.flp', '.frg', '.fsm', '.fzb', '.fzf', '.g721',
                    '.g723', '.g726', '.g722', '.galaxy', '.gig', '.gkp', '.gp5', '.gpbank', '.gpk', '.gpx', '.groove', '.gsm', '.gsp', '.gwp', '.gym', '.h0',
                    '.hdp', '.hma', '.hmi', '.hmi', '.hmw', '.hnx', '.hsb', '.ics', '.iff', '.imf', '.imp', '.ins', '.ins', '.int', '.iti', '.its', '.iti',
                    '.itm', '.itp', '.itx', '.jam', '.kar', '.kfn', '.kit', '.kmp', '.koz', '.koz', '.kpl', '.kpr', '.krz', '.ksd', '.ksc', '.ksf', '.kt2',
                    '.kt3', '.ktp', '.ktz', '.kwi', '.la', '.lof', '.logic', '.lqt', '.lso', '.lvp', '.lwv', '.m3u', '.m4a', '.m4b', '.m4p', '.m4r', '.m4v',
                    '.ma1', '.mbr', '.mcd', '.mcl', '.mcmeta', '.med', '.mgv', '.mid', '.midi', '.miniusf', '.minipsf', '.minipsf2', '.miniusf', '.mjf', '.mka',
                    '.mkj', '.mlp', '.mmf', '.mmlp', '.mmm', '.mmpz', '.mmp', '.mmp', '.mmpz', '.mod', '.mogg', '.mo3', '.mp1', '.mp2', '.mp3', '.mpa',
                    '.mpc', '.mpga', '.mpu', '.mpu', '.mpx', '.mt2', '.mti', '.mtm', '.mtt', '.mxf', '.mxmf', '.myr', '.narrative', '.nbs', '.ncw', '.nds',
                    '.nfa', '.nkb', '.nkc', '.nkm', '.nks', '.nkx', '.nkx', '.note', '.npl', '.nra', '.nrt', '.nsa', '.nsf', '.nsfe', '.ntn', '.nvf', '.nwc',
                    '.odm', '.oga', '.ogg', '.okt', '.oma', '.omf', '.omg', '.omx', '.ots', '.ovw', '.pac', '.pat', '.pbf', '.pca', '.pcast', '.pcg', '.pcm',
                    '.pct', '.pdi', '.pdxi', '.pk', '.pla', '.pls', '.pls', '.ply', '.ppc', '.ppcx', '.prc', '.prg', '.pro', '.psm', '.ptf', '.ptm', '.pts',
                    '.ptx', '.q1', '.qcp', '.r1m', '.ra', '.ram', '.raw', '.rax', '.rbs', '.rcy', '.rex', '.rf64', '.rip', '.rmi', '.rmm', '.rmx', '.rng',
                    '.rns', '.rol', '.rsn', '.rsnd', '.rso', '.rti', '.rtm', '.rtp', '.rvx', '.rx2', '.rxp', '.s3i', '.s3m', '.s3z', '.saf', '.sam', '.sb',
                    '.sbg', '.sbi', '.sbk', '.sc2', '.scl', '.scs', '.sdt', '.sdx', '.seq', '.ses', '.sf', '.sfl', '.shn', '.sid', '.sid', '.sib', '.sid',
                    '.slp', '.smp', '.snd', '.snd', '.sng', '.sou', '.spc', '.spd', '.spl', '.sppack', '.spx', '.sseq', '.sseq', '.ssnd', '.stm', '.stms',
                    '.sxt', '.syh', '.syh', '.syx', '.tak', '.tak', '.tak', '.td0', '.tfmx', '.thx', '.tid', '.tun', '.txw', '.u', '.ub', '.ulaw', '.ult',
                    '.usflib', '.usflib', '.ust', '.uw', '.uwf', '.v2m', '.vag', '.val', '.van', '.vb', '.vbk', '.vc3', '.vcl', '.vdo', '.vdr', '.vem', '.vgm',
                    '.vgz', '.vib', '.vmo', '.voc', '.voc', '.voi', '.vox', '.vpm', '.vqf', '.vrf', '.vsqx', '.vsq', '.vss', '.vsv', '.vtx', '.vtx', '.vtx',
                    '.w01', '.w64', '.wav', '.wax', '.wbk', '.wfb', '.wfd', '.wfp', '.wma', '.wmp', '.wmz', '.wow', '.wpk', '.wproj', '.wv', '.wvc', '.wve',
                    '.wvX', '.wvX', '.wvX', '.wvs', '.xa', '.xa', '.xfs', '.xi', '.xlu', '.xm', '.xm', '.xmf', '.xmz', '.xp', '.xrns', '.xsb', '.xsp', '.xt',
                    '.xwb', '.xwe', '.xwma', '.xwm', '.ym', '.zab', '.zvd'
                    ]


def sum_model(text):
    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
    output = summarizer(text, max_length=130, min_length=30, do_sample=False)
    summary = output[0]['summary_text']
    return summary





def pdf_ult_summrizer(text):
    lang = detect(text)
    if lang == 'en':
        print('English text will be cleanned')
        text = clean_text_fix(text)
    elif lang == 'ar':
        print('Arabic text will be cleanned')
        text = clean_text_fix_ar(text)
        text = translate_text(text, lang, 'en')
    else:
        print('non-ar,non-en text will be cleanned')
        text = translate_text(text, lang, 'en')
        text = clean_text_fix(text)
    # split text into chunks of less than 510 words
    words = text.split()
    chunks = []
    chunk_len = 0
    for word in words:
        if chunk_len + len(word) + 1 <= max_chunck_len:
            if chunk_len > 0:
                chunks[-1] += ' ' + word
            else:
                chunks.append(word)
            chunk_len += len(word) + 1
        else:
            chunks.append(word)
            chunk_len = len(word)
    # apply summarization functions to each chunk and merge the results
    summary_s = []
    for chunk in tqdm(chunks, desc="Summrizing chunks", unit="chunk"):
        summarys = sum_model(chunk)
        summary_s.append(summarys)
    # join the summaries into strings
    summary = '\n'.join(summary_s)
    if lang != 'en':
        summary_s = translate_text(summary_s, 'en', lang)
    return summary


def get_summarized_pdf(pdf_path):
    # Create a temporary DOCX file
    docx_file_name = os.path.splitext(pdf_path)[0] + '_summarized.docx'
    doc = Document()

    # Open the PDF file
    with open(pdf_path, 'rb') as pdf_file:
        pdf_reader = PyPDF2.PdfReader(pdf_file)

        # Loop over each page of the PDF
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]

            # Extract page style
            page_style = {}
            if '/Resources' in page:
                resources = page['/Resources']
                if '/Font' in resources:
                    page_style['fonts'] = resources['/Font']
                if '/ColorSpace' in resources:
                    page_style['colors'] = resources['/ColorSpace']

            # Extract text and style information
            text = page.extract_text()  # Strip whitespace from the text
            if not text:  # Skip empty pages
                continue
            font_counts = {}
            font_sizes = {}
            color_counts = {}
            for word in page:
                if hasattr(word, 'getFont'):
                    font_name = word.getFont()['/BaseFont']
                    font_size = word.fontSize
                    color = word.textColor

                    font_counts[font_name] = font_counts.get(font_name, 0) + 1
                    font_sizes[font_size] = font_sizes.get(font_size, 0) + 1
                    color_counts[color] = color_counts.get(color, 0) + 1

            # Get the most used font, size, and color
            if font_counts:
                font_name = max(font_counts, key=font_counts.get)
            else:
                font_name = 'Arial'
            if font_sizes:
                font_size = max(font_sizes, key=font_sizes.get)
            else:
                font_size = 14
            if color_counts:
                text_color = RGBColor(
                    *max(color_counts, key=color_counts.get).as_rgb())
            else:
                text_color = RGBColor(0, 0, 0)

            # Summarize the text
            summary = pdf_ult_summrizer(text)
            # Add the summarized text to the DOCX file
            if page_num > 0:
                doc.add_page_break()
            new_paragraph = doc.add_paragraph(style=doc.styles['Normal'])
            new_run = new_paragraph.add_run(summary)
            new_run.font.name = font_name
            new_run.font.size = Pt(font_size)
            new_run.font.color.rgb = text_color

    # Save the DOCX file and convert it to PDF
    pdf_file_name = os.path.splitext(pdf_path)[0]
    pdf_file_name += f"_{''.join(random.choices(string.ascii_uppercase + string.digits, k=8))}_summarized.pdf"

    for paragraph in doc.paragraphs:
        if paragraph.style.name == 'List Paragraph':
            # Convert numbered sentences to a list
            paragraph.style = 'List Bullet'
    doc.save(docx_file_name)
    convert(docx_file_name, pdf_file_name)
    os.remove(docx_file_name)
    # Return the new PDF file location
    final_pdf_name = pdf_file_name.replace('media\\', '')
    return final_pdf_name


def is_video_file(filename):
    ext = os.path.splitext(filename)[-1].lower()
    return ext in video_extensions


def get_text_from_video(media_path):
    if is_video_file(media_path):
        video = mp.VideoFileClip(media_path)
        language_model_path = "en-us"
        audio_file = "audio_file.wav"
        video.audio.write_audiofile(audio_file)
        r = sr.Recognizer()
        with sr.AudioFile(audio_file) as source:
            audio_data = r.record(source)
            text = r.recognize_sphinx(audio_data, language=language_model_path)
        os.remove(audio_file)
    else:
        audio_file = "audio_file.wav"
        y, sr2 = sf.read(media_path)
        sf.write(audio_file, y, sr2, subtype='PCM_16')
        r = sr.Recognizer()
        with sr.AudioFile(audio_file) as source:
            audio_data = r.record(source)
            text = r.recognize_sphinx(audio_data, language="en-us")
        os.remove(audio_file)
    return text


def get_text_from_url(url):
    # Extract the text content from the URL using BeautifulSoup if it's a Wikipedia page
    if 'wikipedia.org' in url:
        print('wikipedia site detected')
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')
        for div in soup.select('#siteSub, .hatnote.navigation-not-searchable, .infobox.ib-country.vcard, .thumb.tright,.thumb.tleft,.IPA, .thumb.tnone, .reflist, [role="note"]'):
            div.extract()
        body_content = soup.find(id='bodyContent')
        p_tags = body_content.find_all('p')
        text = '\n'.join([p.get_text() for p in p_tags])
    # Otherwise, use the newspaper library to extract the text content
    else:
        print('other website detected')
        article = Article(url)
        article.download()
        article.parse()
        text = article.text

    # Remove reference numbers
    text = re.sub(r'\[\d+\]', '', text)

    print('the website is live')
    # Remove extra whitespace and line breaks
    text = re.sub(r'\n+', '\n', text)
    text = text.strip()

    # Split the text into sentences
    sentences = sent_tokenize(text)

    # Remove sentences that are too short or contain only special characters
    sentences = [s for s in sentences if len(
        s) > 20 and re.search('[a-zA-Z0-9]', s)]

    # Join the remaining sentences into a single string
    text = ' '.join(sentences)
    return text


def clean_text_fix(text):
    tool = language_tool_python.LanguageTool('en-US')
    print('Cleaning the text')
    # Remove text enclosed in parentheses and less than or equal to 10 words
    text = re.sub(r'\([^)]{1,30}\s?\b\w{0,9}\b\s?[^\)]*\)', '', text)
    # Remove square brackets and their contents if they contain numbers only
    text = re.sub(r'\[[^\]]*\b\d+\b[^\]]*\]', '', text)
    # Remove punctuation except in numbered sentences and at the end of lines
    text = re.sub(
        r'(?<!\d)(?<!\d\.)[^\w\s]+(?!\.\d)(?!\d\.)(?<!\.)', ' ', text)
    # Remove extra line breaks and spaces
    text = re.sub('\n\n+', '\n', "".join(line.strip()
                  for line in text.split("\n") if line.strip()))
    # Start a new line if a numbered sentence is present
    text = re.sub(r'(\d+\.)', r'\n\n\1', text)
    text = re.sub(r'(\d+)([a-zA-Z])', r'\1 \2', text)
    text = re.sub(r'([a-zA-Z])(\d+)', r'\1 \2', text)
    # Convert all text to lowercase
    text = text.lower()
    corrected_text = tool.correct(text)
    print('Cleaning the text is done')
    return corrected_text


def clean_text_fix_ar(text):
    corr = Corrector()
    print('Cleaning the text')
    # Remove text enclosed in parentheses and less than or equal to 10 words
    text = re.sub(r'\([^)]{1,30}\s?\b\w{0,9}\b\s?[^\)]*\)', '', text)
    # Remove square brackets and their contents if they contain numbers only
    text = re.sub(r'\[[^\]]*\b\d+\b[^\]]*\]', '', text)
    # Remove punctuation except in numbered sentences and at the end of lines
    text = re.sub(
        r'(?<!\d)(?<!\d\.)[^\w\s]+(?!\.\d)(?!\d\.)(?<!\.)', ' ', text)
    # Remove extra line breaks and spaces
    text = re.sub('\n\n+', '\n', "".join(line.strip()
                  for line in text.split("\n") if line.strip()))
    # Start a new line if a numbered sentence is present
    text = re.sub(r'(\d+\.)', r'\n\n\1', text)
    text = re.sub(r'(\d+)([a-zA-Z])', r'\1 \2', text)
    text = re.sub(r'([a-zA-Z])(\d+)', r'\1 \2', text)
    # Convert all text to lowercase
    text = text.lower()
    corrected_text = corr.contextual_correct(text)
    print('Cleaning the text is done')
    return corrected_text


def ult_summrizer(text):
    lang = detect(text)
    if lang == 'en':
        print('English text will be cleanned')
        text = clean_text_fix(text)
    elif lang == 'ar':
        print('Arabic text will be cleanned')
        text = clean_text_fix_ar(text)
        text = translate_text(text, lang, 'en')
    else:
        print('non-ar,non-en text will be cleanned')
        text = translate_text(text, lang, 'en')
        text = clean_text_fix(text)
    # split text into chunks of less than 510 words
    words = text.split()
    chunks = []
    chunk_len = 0
    for word in words:
        if chunk_len + len(word) + 1 <= max_chunck_len:
            if chunk_len > 0:
                chunks[-1] += ' ' + word
            else:
                chunks.append(word)
            chunk_len += len(word) + 1
        else:
            chunks.append(word)
            chunk_len = len(word)
    print(chunks)
    # apply summarization functions to each chunk and merge the results
    oursummarys_s = []
    for chunk in tqdm(chunks, desc="Summrizing chunks", unit="chunk"):
        oursummarys1 = sum_model(chunk)

        oursummarys_s.append(oursummarys1)
    # join the summaries into strings
    oursummarys = ' '.join(oursummarys_s)

    if lang != 'en':
        oursummarys = translate_text(oursummarys, 'en', lang)

    return oursummarys


def translate_text(text, lang, dest2):
    max_t_chunk_len = 2000
    chunks = []
    chunk_len = 0
    # Split the input text into chunks that are less than 5000 characters
    words = text.split(' ')
    for word in words:
        if chunk_len + len(word) + 1 <= max_t_chunk_len:
            if chunk_len > 0:
                chunks[-1] += ' ' + word
            else:
                chunks.append(word)
            chunk_len += len(word) + 1
        else:
            chunks.append(word)
            chunk_len = len(word)
    # Translate each chunk separately and join them back together
    translated_chunks = []
    for chunk in tqdm(chunks, desc="Translating chunks", unit="chunk"):
        translator = Translator()
        translated_chunk = translator.translate(
            chunk, src=lang, dest=dest2).text
        translated_chunks.append(translated_chunk)
    translated_text = ' '.join(translated_chunks)
    return translated_text

















# Create your views here.

def loginn(request):

   if not request.user.is_authenticated:

        if request.method=="POST":

            username = request.POST['username']

            password1 = request.POST['pass1']


            us = authenticate(request,username=username, password=password1)


            if us is not None:


                login(request, us)


                u = User.objects.get(username=username)


                return redirect( 'index')
            else:

                messages.error(request, 'ataced mn al username aw elpass')
        return render(request, 'login.html')
   else :
       return redirect('index')


def logoutt(request):
    logout(request)
    messages.success(request, 'you are logged out')
    return redirect('state')


@login_required
def status(request):
    fname1 = request.user.first_name
    lname1 = request.user.last_name
    fullname2 = fname1 + ' ' + lname1
    femail = request.user.email.strip().lower()
    femail_hash = hashlib.md5(femail.encode('utf-8')).hexdigest()
    return render(request, 'status.html', {"fullname2": fullname2, "fname": fname1, "femail": femail_hash})


def state(request):
    return render(request, 'state.html')


def reg(request):
    if not  request.user.is_authenticated:
        if request.method == 'POST':
            username = request.POST['username']
            fname = request.POST['fname']
            lname = request.POST['lname']
            email1 = request.POST['email']
            password1 = request.POST['pass1']
            password2 = request.POST['pass2']
            if User.objects.filter(username=username):
                messages.error(request, 'The user already exist')
                return redirect('state')
            elif User.objects.filter(email=email1):
                messages.error(request, 'This Email is already Regesterid')
                return redirect('state')
            elif len(username) < 8 or len(username) > 20:
                messages.error(request, 'the username len msut be 8 to 20 chars')
                return redirect('state')
            elif password1 != password2:
                messages.error(request, "Passwords dosen't match")
                return redirect('state')
            elif not username.isalnum():
                messages.error(request, 'Username must be alphabetic')
                return redirect('state')
            else:
                myuser = User.objects.create_user(username, email1, password1)
                myuser.first_name = fname
                myuser.last_name = lname
                myuser.is_active = True

                myuser.save()
                return redirect('loginn')

        return render(request, 'reg.html')
    else :
        return redirect('index')


#################################################################################

d = {"hi":
     "hi,there",
     "What's your name?":
     "I am just a chatbot",
     "What's your fav food":
     "I like nothing",
     "what's your fav sport":
     "I like all sports",
     "do you have children":
     "no"
     }

#list_trainer = ListTrainer(bot)
#list_trainer.train(list_to_train)

# chatterbotCorpusTrainer = ChatterBotCorpusTrainer(bot)

# chatterbotCorpusTrainer.train('chatterbot.corpus.english')


bad_words = ["2 girls 1 cup", "4r5e", "anal", "anus", "areole", "arian", "arrse", "arse", "arsehole", "aryan", "aSanchez", "ass", "ass-fucker", "assbang", "assbanged", "asses", "assfuck", "assfucker", "assfukka", "asshole", "assmunch", "asswhole", "auto erotic", "autoerotic", "ballsack", "bastard", "bdsm", "beastial", "beastiality", "bellend", "bestial", "bestiality", "bimbo", "bimbos", "bitch", "bitches", "bitchin", "bitching", "blow job", "blowjob", "blowjobs", "blue waffle", "bondage", "boner", "boob", "boobs", "booobs", "boooobs", "booooobs", "booooooobs", "booty call", "breasts", "brown shower", "brown showers", "buceta", "bukake", "bukkake", "bull shit", "bullshit", "busty", "butthole", "carpet muncher", "cawk", "chink", "cipa", "clit", "clitoris", "clits", "cnut", "cock", "cockface", "cockhead", "cockmunch", "cockmuncher", "cocks", "cocksuck", "cocksucked", "cocksucker", "cocksucking", "cocksucks", "cokmuncher", "coon", "cow girl", "cow girls", "cowgirl", "cowgirls", "crap", "crotch", "cum", "cuming", "cummer", "cumming", "cums", "cumshot", "cunilingus", "cunillingus", "cunnilingus", "cunt", "cuntlicker", "cuntlicking", "cunts", "damn", "deep throat", "deepthroat", "dick", "dickhead", "dildo", "dildos", "dink", "dinks", "dlck", "dog style", "dog-fucker", "doggie style", "doggie-style", "doggiestyle", "doggin", "dogging", "doggy style", "doggy-style", "doggystyle", "dong", "donkeyribber", "doofus", "doosh", "dopey", "douch3", "douche", "douchebag", "douchebags", "douchey", "drunk", "duche", "dumass", "dumbass", "dumbasses", "dummy", "dyke", "dykes", "eatadick", "eathairpie", "ejaculate", "ejaculated", "ejaculates", "ejaculating", "ejaculatings", "ejaculation", "ejakulate", "enlargement", "erect", "erection", "erotic", "erotism", "essohbee", "extacy", "extasy", "f_u_c_k", "f-u-c-k", "f.u.c.k", "f4nny", "facial", "fack", "fag", "fagg", "fagged", "fagging", "faggit", "faggitt", "faggot", "faggs", "fagot", "fagots", "fags", "faig", "faigt", "fanny", "fannybandit", "fannyflaps", "fannyfucker", "fanyy", "fart", "fartknocker", "fat", "fatass", "fcuk", "fcuker", "fcuking", "feck", "fecker", "felch", "felcher", "felching", "fellate", "fellatio", "feltch", "feltcher", "femdom", "fingerfuck", "fingerfucked", "fingerfucker", "fingerfuckers", "fingerfucking", "fingerfucks", "fingering", "fisted", "fistfuck", "fistfucked", "fistfucker", "fistfuckers", "fistfucking", "fistfuckings", "fistfucks", "fisting", "fisty", "flange", "flogthelog", "floozy", "foad", "fondle", "foobar", "fook", "fooker", "foot job", "footjob", "foreskin", "freex", "frigg", "frigga", "fubar", "fuck", "fuck-ass", "fuck-bitch", "fuck-tard", "fucka", "fuckass", "fucked", "fucker", "fuckers", "fuckface", "fuckhead", "fuckheads", "fuckhole", "fuckin", "fucking", "fuckings", "fuckingshitmotherfucker", "fuckme", "fuckmeat", "fucknugget", "fucknut", "fuckoff", "fuckpuppet", "fucks", "fucktard", "fucktoy", "fucktrophy", "fuckup", "fuckwad", "fuckwhit", "fuckwit", "fuckyomama", "fudgepacker", "fuk", "fuker", "fukker", "fukkin", "fukking", "fuks", "fukwhit", "fukwit", "futanari", "futanary", "fux", "fux0r", "fvck", "fxck", "g-spot", "gae", "gai", "gang bang", "gang-bang", "gangbang", "gangbanged", "gangbangs", "ganja", "gassyass", "gay", "gaylord", "gays", "gaysex", "gey", "gfy", "ghay", "ghey", "gigolo", "glans", "goatse", "god", "god-dam", "god-damned", "godamn", "godamnit", "goddam", "goddammit", "goddamn", "goddamned", "gokkun", "golden shower", "goldenshower", "gonad", "gonads", "gook", "gooks", "gringo", "gspot", "gtfo", "guido", "h0m0", "h0mo", "hamflap", "hand job", "handjob", "hardcoresex", "hardon", "he11", "hebe", "heeb", "hell", "hemp", "hentai", "heroin", "herp", "herpes", "herpy", "heshe", "hitler", "hiv", "hoar", "hoare", "hobag", "hoer", "hom0", "homey", "homo", "homoerotic", "homoey", "honky", "hooch", "hookah", "hooker", "hoor", "hootch", "hooter", "hooters", "hore", "horniest", "horny", "hotsex", "howtokill", "howtomurdep", "hump", "humped", "humping", "hussy", "hymen", "inbred", "incest", "injun", "j3rk0ff", "jack off", "jack-off", "jackass", "jackhole", "jackoff", "jap", "japs", "jerk", "jerk off", "jerk-off", "jerk0ff", "jerked", "jerkoff", "jism", "jiz", "jizm", "jizz", "jizzed", "junkie", "junky", "kawk", "kike", "kikes", "kill", "kinbaku", "kinky", "kinkyJesus", "kkk", "klan", "knob", "knobead", "knobed", "knobend", "knobhead", "knobjocky", "knobjokey", "kock", "kondum", "kondums", "kooch", "kooches", "kootch", "kraut", "kum", "kummer", "kumming", "kums", "kunilingus", "kwif", "kyke", "l3i+ch", "l3itch", "labia", "lech", "LEN", "leper", "lesbians", "lesbo", "lesbos", "lez", "lezbian", "lezbians", "lezbo", "lezbos", "lezzie", "lezzies", "lezzy", "lmao", "lmfao", "loin", "loins", "lube", "lust", "lusting", "lusty", "m-fucking", "m0f0", "m0fo", "m45terbate", "ma5terb8", "ma5terbate", "mafugly", "mams", "masochist", "massa", "master-bate",
   "masterb8", "masterbat*", "masterbat3", "masterbate", "masterbating", "masterbation", "masterbations", "masturbate", "masturbating", "masturbation", "maxi", "menses", "menstruate", "menstruation", "meth", "milf", "mo-fo", "mof0", "mofo", "molest", "moolie", "moron", "mothafuck", "mothafucka", "mothafuckas", "mothafuckaz", "mothafucked", "mothafucker", "mothafuckers", "mothafuckin", "mothafucking", "mothafuckings", "mothafucks", "mother fucker", "motherfuck", "motherfucka", "motherfucked", "motherfucker", "motherfuckers", "motherfuckin", "motherfucking", "motherfuckings", "motherfuckka", "motherfucks", "mtherfucker", "mthrfucker", "mthrfucking", "muff", "muffdiver", "muffpuff", "murder", "mutha", "muthafecker", "muthafuckaz", "muthafucker", "muthafuckker", "muther", "mutherfucker", "mutherfucking", "muthrfucking", "n1g", "n1gg", "n1gga", "n1gger", "nad", "nads", "naked", "napalm", "nappy", "nazi", "nazism", "needthedick", "negro", "nig", "nigg", "nigg3r", "nigg4h", "nigga", "niggah", "niggas", "niggaz", "nigger", "niggers", "niggle", "niglet", "nimrod", "ninny", "nipple", "nipples", "nob", "nob jokey", "nobhead", "nobjocky", "nobjokey", "nooky", "nude", "nudes", "numbnuts", "nutbutter", "nutsack", "nympho", "omg", "opiate", "opium", "oral", "orally", "organ", "orgasim", "orgasims", "orgasm", "orgasmic", "orgasms", "orgies", "orgy", "ovary", "ovum", "ovums", "p.u.s.s.y.", "p0rn", "paddy", "paki", "pantie", "panties", "panty", "pastie", "pasty", "pawn", "pcp", "pecker", "pedo", "pedophile", "pedophilia", "pedophiliac", "pee", "peepee", "penetrate", "penetration", "penial", "penile", "penis", "penisfucker", "perversion", "peyote", "phalli", "phallic", "phonesex", "phuck", "phuk", "phuked", "phuking", "phukked", "phukking", "phuks", "phuq", "pigfucker", "pillowbiter", "pimp", "pimpis", "pinko", "piss", "piss-off", "pissed", "pisser", "pissers", "pisses", "pissflaps", "pissin", "pissing", "pissoff", "playboy", "pms", "polack", "pollock", "poon", "poontang", "poop", "porn", "porno", "pornography", "pornos", "pot", "potty", "prick", "pricks", "prig", "pron", "prostitute", "prude", "pube", "pubic", "pubis", "punkass", "punky", "puss", "pusse", "pussi", "pussies", "pussy", "pussyfart", "pussypalace", "pussypounder", "pussys", "puto", "queaf", "queef", "queer", "queero", "queers", "quicky", "quim", "r-tard", "racy", "rape", "raped", "raper", "raping", "rapist", "raunch", "rectal", "rectum", "rectus", "reefer", "reetard", "reich", "retard", "retarded", "revue", "rimjaw", "rimjob", "rimming", "ritard", "rtard", "rum", "rump", "rumprammer", "ruski", "s_h_i_t", "s-h-1-t", "s-h-i-t", "s-o-b", "s.h.i.t.", "s.o.b.", "s0b", "sadism", "sadist", "sandbar", "sausagequeen", "scag", "scantily", "schizo", "schlong", "screw", "screwed", "screwing", "scroat", "scrog", "scrot", "scrote", "scrotum", "scrud", "scum", "seaman", "seamen", "seduce", "semen", "sex", "sexual", "sh!+", "sh!t", "sh1t", "shag", "shagger", "shaggin", "shagging", "shamedame", "she male", "shemale", "shi+", "shibari", "shibary", "shit", "shitdick", "shite", "shiteater", "shited", "shitey", "shitface", "shitfuck", "shitfucker", "shitfull", "shithead", "shithole", "shithouse", "shiting", "shitings", "shits", "shitt", "shitted", "shitter", "shitters", "shitting", "shittings", "shitty", "shiz", "shota", "sissy", "skag", "skank", "slave", "sleaze", "sleazy", "slope", "slut", "slutbucket", "slutdumper", "slutkiss", "sluts", "smegma", "smut", "smutty", "snatch", "sniper", "snuff", "sodom", "son-of-a-bitch", "souse", "soused", "spac", "sperm", "spic", "spick", "spik", "spiks", "spooge", "spunk", "steamy", "stfu", "stiffy", "stoned", "strip", "strip club", "stripclub", "stroke", "stupid", "suck", "sucked", "sucking", "sumofabiatch", "t1t", "t1tt1e5", "t1tties", "tampon", "tard", "tawdry", "teabagging", "teat", "teets", "teez", "terd", "teste", "testee", "testes", "testical", "testicle", "testis", "three some", "threesome", "throating", "thrust", "thug", "tinkle", "tit", "titfuck", "titi", "tits", "titt", "tittie5", "tittiefucker", "titties", "titty", "tittyfuck", "tittyfucker", "tittywank", "titwank", "toke", "toots", "tosser", "tramp", "transsexual", "trashy", "tubgirl", "turd", "tush", "tw4t", "twat", "twathead", "twats", "twatty", "twunt", "twunter", "ugly", "undies", "unwed", "urinal", "urine", "uterus", "uzi", "v14gra", "v1gra", "vag", "vagina", "valium", "viagra", "virgin", "vixen", "vodka", "vomit", "voyeur", "vulgar", "vulva", "w00se", "wad", "wang", "wank", "wanker", "wanky", "wazoo", "wedgie", "weed", "weenie", "weewee", "weiner", "weirdo", "wench", "wetback", "wh0re", "wh0reface", "whitey", "whiz", "whoar", "whoralicious", "whore", "whorealicious", "whored", "whoreface", "whorehopper", "whorehouse", "whores", "whoring", "wigger", "willies", "willy", "womb", "woody", "wop", "wtf", "x-rated2g1c", "xx", "xxx", "yaoi", "yury"]  # Add your list of bad words here


def contains_bad_word(u_message):
    substitutions = {
        "a": ("a", "@", "*", "4"),
        "i": ("i", "*", "l", "1"),
        "o": ("o", "*", "0", "@"),
        "u": ("u", "*", "v"),
        "v": ("v", "*", "u"),
        "l": ("l", "1"),
        "e": ("e", "*", "3"),
        "s": ("s", "$", "5"),
        "t": ("t", "7"),
    }

    # Convert the user message to lowercase for case-insensitive comparison
    u_message = u_message.lower()

    for word in u_message.split():
        for char in substitutions:
            variations = substitutions[char]
            for variation in variations:
                word = word.replace(variation, char)

        if word in bad_words:
            return True

    return False


def googlesearchtry(query):
    search_results = list(search(query, num_results=1))
    if search_results:
        # Get the first search result URL
        first_result = search_results[0]
        second_result = search_results[1]
        go_result = search_results[2]
        go_result2 = search_results[3]
        go_result3 = search_results[4]
        result += """<h1 style="
    color: #ffffff;
    width: 100%;
    font-weight: bold;
    padding: 5px;
    border-radius: 15px 0 15px 0;
    text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF;
    background: rgb(92,248,255);
    background: linear-gradient(-120deg, #4285f4, #34a853, #fbbc05, #ea4335);
    -webkit-text-stroke: 1px black;
    ">Google Search Result</h1>"""
        result += "\n<span>" + first_result + "</span>"
        result += "\n<span>" + second_result + "</span>"
        result += "\n<span>" + go_result + "</span>"
        result += "\n<span>" + go_result2 + "</span>"
        result += "\n<span>" + go_result3 + "</span>"
    else:
        result += "I'm sorry I couldn't help you with that at the moment try asking me somthing else"
    return result


def search_information(query):
    result = ""
    try:
        # Search on Wikipedia
        wiki_wiki = wikipediaapi.Wikipedia('en')
        page = wiki_wiki.page(query)

        if page.exists():
            result += """<h1 style="color: #000000;font-weight: bold;width: 100%;padding: 5px;border-radius: 15px 0 15px 0;background: rgb(92,248,255);background: linear-gradient(90deg, rgba(92,248,255,1) 0%, rgba(187,255,249,1) 50%, rgba(230,156,255,1) 100%);">Wikipedia Summary</h1>"""
            result += f"""<p style="text-align: center;">{page.summary}</p>"""
            result += """<h1 style="color: #ffffff;">Full Wikipedia URL</h1>"""
            result += f"\n{page.fullurl}"
        else:
            try:
                result = googlesearchtry(query)
            except Exception as e:
                return "I'm sorry I couldn't help you with that at the moment try asking me somthing else"
    except Exception as e:
        try:
            result = googlesearchtry(query)
        except Exception as e:
            return """ I'm having some problems i can only summarize text at the moment put the text inside "" like this:\n "this is a text to summarize" or just chose a media file  """
    return result


def chatbot(u_message, mtype):
    if mtype == "text":
        if '"' in u_message:
            start_index = u_message.index('"') + 1
            end_index = u_message.index('"', start_index)
            text_inside_quotes = u_message[start_index:end_index]
            return ult_summrizer(text_inside_quotes)
        else:
            anstest = chatbotans(u_message)
            if anstest == "no":
                return search_information(u_message)
            else:
                return anstest
    else:
        file_extension = os.path.splitext(u_message)[-1].lower()
        if file_extension == ".pdf":
            newfilename_encoded = get_summarized_pdf(f"media\\{u_message}")
            file_url2 = "'siteurlreplaceinchat'" + \
                settings.MEDIA_URL + newfilename_encoded
            return file_url2
        elif file_extension in video_extensions or file_extension in audio_extensions:
            textinvid = get_text_from_video(f"media\\{u_message}")
            return ult_summrizer(textinvid)
        else:
            return "Unsupported file type"




# Example usage


@login_required
def index(request):
        fname1 = request.user.first_name
        lname1 = request.user.last_name
        femail = request.user.email.strip().lower()
        femail_hash = hashlib.md5(femail.encode('utf-8')).hexdigest()
        fullname2 = fname1 + ' ' + lname1
        chats = Massages.objects.filter(user=request.user).order_by('pk')

        return render(request, 'index.html', {"chats": chats, "fullname2": fullname2, "fname1": fname1, "femail": femail_hash})


# Profile
@login_required
def profile(request):
    fname1 = request.user.first_name
    lname1 = request.user.last_name
    fullname2 = fname1 + ' ' + lname1
    femail = request.user.email.strip().lower()
    femail_hash = hashlib.md5(femail.encode('utf-8')).hexdigest()

    if request.method == 'POST':
        fname = request.POST['efname']
        lname = request.POST['elname']
        email1 = request.POST['eemail']
        password1 = request.POST['epass1']

        if User.objects.filter(email=email1).exclude(username=request.user.username).exists():
            messages.error(request, 'This email is already exist.')
            return redirect('status')
        else:
            user = request.user
            user.email = email1
            if password1:
                user.set_password(password1)
            user.first_name = fname
            user.last_name = lname
            user.save()

            messages.success(request, 'Profile updated successfully.')
            return redirect('profile')
    else:
        return render(request, 'profile.html', {
            "fullname2": fullname2,
            "fname1": fname1,
            "lname1": lname1,
            "femail": femail_hash,
            "femail2": femail
        })

#anslsis
@login_required
def anslsis(request):
    fname1 = request.user.first_name
    lname1 = request.user.last_name
    fullname2 = fname1 + ' ' + lname1
    femail = request.user.email.strip().lower()
    femail_hash = hashlib.md5(femail.encode('utf-8')).hexdigest()
    chats = Massages.objects.order_by('pk')

    message_count = len(chats)
    text_in_quotes_count = 0
    hi_count = 0
    how_count = 0
    one_count = 0
    word_count_massages = 0
    word_count_replies = 0
    failsum = 0
    
    for chat in chats:
        if chat.massages and '"' in chat.massages:
            text_in_quotes_count += 1
            word_count_massages += len(chat.massages.split())
            if chat.replay:
                word_count_replies += len(chat.replay.split())
            else:
                failsum += 1
        elif chat.massages and 'siteurlreplaceinchat' in chat.massages:
            text_in_quotes_count += 1
            word_count_massages += len(chat.massages.split())
            if chat.replay:
                word_count_replies += len(chat.replay.split())
            else:
                failsum += 1
        elif chat.massages and chat.massages.lower() == "hi":
            hi_count += 1
        elif chat.massages and "how" in chat.massages.lower():
            how_count += 1
        elif chat.massages and len(chat.massages.split()) == 1 and chat.massages.lower() not in ["hi", "how"]:
            one_count += 1

    ans = text_in_quotes_count + hi_count + one_count + how_count
    other_count = message_count - ans
    results = {
        "hi_count": hi_count,
        "how_count": how_count,
        "text_in_quotes_count": text_in_quotes_count,
        "one_count": one_count,
        "other_count": other_count,
        "word_count_massages": word_count_massages,
        "word_count_replies": word_count_replies,
        "failsum": failsum
    }
    results_json = json.dumps(results)
    return render(request, 'anslsis.html', {"fullname2": fullname2, "fname1": fname1, "femail": femail_hash, "results_json": results_json})


#new
@login_required
def new(request):
    fname1 = request.user.first_name
    lname1 = request.user.last_name
    fullname2 = fname1 + ' ' + lname1
    femail = request.user.email.strip().lower()
    femail_hash = hashlib.md5(femail.encode('utf-8')).hexdigest()
    return render(request, 'new.html', {"fullname2": fullname2, "fname1": fname1, "femail": femail_hash})


@login_required
def ourteam(request):
    fname1 = request.user.first_name
    lname1 = request.user.last_name
    fullname2 = fname1 + ' ' + lname1
    femail = request.user.email.strip().lower()
    femail_hash = hashlib.md5(femail.encode('utf-8')).hexdigest()
    return render(request, 'ourteam.html', {"fullname2": fullname2, "fname1": fname1, "femail": femail_hash})






@login_required()
def getResponse(request):
    if request.method == 'POST':
        user_message = request.POST.get('userMessage')
        file = request.FILES.get('file')
        chat_response = "i'm having an update pleas come later"
        # Save the file to the media folder
        if file:
            filename = default_storage.save(file.name, file)
            filename_encoded = urllib.parse.quote(filename)
            file_url = request.scheme + '://' + \
                request.get_host() + settings.MEDIA_URL + filename_encoded
            file_url2 = "'siteurlreplaceinchat'" + \
                settings.MEDIA_URL + filename_encoded 
            user_message = file_url2
            chat_response = chatbot(filename_encoded, mtype="file")
        else:
            file_url = None

            if contains_bad_word(user_message):
                # Replace bad words with asterisks
                words = user_message.split()
                filtered_words = []

                for word in words:
                    if word.lower() in bad_words:
                        word = "*" * len(word)

                    filtered_words.append(word)

                user_message = " ".join(filtered_words)
                chat_response = "That's not nice"
            else:
                chat_response = chatbot(user_message, mtype="text")





        # Process the user message and generate a response

        # Save the message and response to the database
        current_timestamp = timezone.now()
        formatted_timestamp = current_timestamp.strftime("%B %d, %Y, %I:%M %p")  # June 13, 2023, 1:01 p.m.
        Massages.objects.create(massages=user_message,
                                user=request.user, replay=chat_response)
        # Prepare the data to send back to the client
        data = {
            "file_link": file_url,
            "response": chat_response,
            "user_message": user_message,
            "timestamp": formatted_timestamp,
        }

        return JsonResponse(data)

    return JsonResponse({"error": "Invalid request"})
