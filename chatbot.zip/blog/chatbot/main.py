import os
import pickle
import json
import random
import tflearn
import tensorflow as tf
import numpy
from nltk.stem.lancaster import LancasterStemmer
import nltk
import warnings
from django.conf import settings

warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

# Assuming this file is in a folder within the views folder
current_folder = os.path.dirname(os.path.abspath(__file__))

# Navigate up two levels to the 'blog' folder, then enter the 'chatbot' folder
chatbot_folder = os.path.join(current_folder, '..', 'chatbot')

# Construct absolute paths using the chatbot_folder
intents_path = os.path.join(chatbot_folder, 'intents.json')
model_path = os.path.join(chatbot_folder, 'model.tflearn')
pickle_path = os.path.join(chatbot_folder, 'data.pickle')

stemmer = LancasterStemmer()

with open(intents_path) as file:
    data = json.load(file)
with open(pickle_path, "rb") as f:
    words, labels, training, output = pickle.load(f)

tf.compat.v1.reset_default_graph()

net = tflearn.input_data(shape=[None, len(training[0])])
net = tflearn.fully_connected(net, 8)
net = tflearn.fully_connected(net, 8)
net = tflearn.fully_connected(net, len(output[0]), activation="softmax")
net = tflearn.regression(net)

model = tflearn.DNN(net)
# Specify the file path for the model file
model_file_path = model_path
model.load(model_file_path)


def bag_of_words(s, words):
    bag = [0] * len(words)

    s_words = nltk.word_tokenize(s)
    s_words = [stemmer.stem(word.lower()) for word in s_words]

    for se in s_words:
        for i, w in enumerate(words):
            if w == se:
                bag[i] = 1
    return numpy.array(bag)


def chatbotans(inp):
    results = model.predict([bag_of_words(inp.lower(), words)])[0]
    results_index = numpy.argmax(results)
    tag = labels[results_index]
    if results[results_index] > 0.1:
        for tg in data["intents"]:
            if tg['tag'] == tag:
                responses = tg['responses']
        Bot = random.choice(responses)
        return Bot
    else:
        return "no"
